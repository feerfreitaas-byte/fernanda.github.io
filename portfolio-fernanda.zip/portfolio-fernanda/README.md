# Portfólio — Fernanda

Portfólio profissional de Recrutamento & Seleção: projetos, estudo de caso interativo, perfil e contato.

Site estático em um único arquivo (`index.html`), sem dependências de build. As fontes vêm do Google Fonts.

## Publicar no GitHub Pages

1. Suba o `index.html` na raiz do repositório.
2. Vá em **Settings → Pages**.
3. Em **Source**, escolha **Deploy from a branch**, branch `main` e pasta `/ (root)`, e clique em **Save**.
4. Em alguns minutos o site fica no ar em `https://SEU-USUARIO.github.io/NOME-DO-REPO/`.

Dica: se o repositório se chamar `SEU-USUARIO.github.io`, o endereço fica só `https://SEU-USUARIO.github.io/`.

## Editar conteúdo

Tudo que muda com frequência está no `<script>` do final do arquivo:

- `CONTATO`: links de contato (LinkedIn etc.)
- `P`: lista de projetos do quadro (título, problema, solução, resultado e tags)
- `SK`: abas de competências
- `TR`: trajetória profissional
